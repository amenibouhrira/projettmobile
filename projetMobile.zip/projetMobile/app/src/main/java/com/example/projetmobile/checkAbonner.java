package com.example.projetmobile;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class checkAbonner extends AppCompatActivity {
TextView comm;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_abonner);
        comm=findViewById(R.id.abonnerchecked);
        Intent intentAbn =getIntent();

         comm.setText(String.format("congrats%svous êtes réservé à%sde%sà%s%s%svotre QR code est ",
                 intentAbn.getStringExtra("username"),
                 intentAbn.getStringExtra("transport"),
                 intentAbn.getStringExtra("position"),
                 intentAbn.getStringExtra("destination"),
                 "qui sera expiré ", intentAbn.getStringExtra("periode")));
    }
}