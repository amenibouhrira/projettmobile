package com.example.projetmobile;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class checkReserverActivity extends AppCompatActivity {
TextView resultat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_reserver);
        resultat=findViewById(R.id.reserverChecked);
        Intent intentRes=getIntent();
        resultat.setText(String.format("congrats%svous êtes réservé à%sde%sà%sle%sde%s:%squi sera expiré %s",
                intentRes.getStringExtra("username"), intentRes.getStringExtra("transport"),
                intentRes.getStringExtra("position"), intentRes.getStringExtra("destination"),
                intentRes.getStringExtra("date"), intentRes.getStringExtra("heure"),
                intentRes.getStringExtra("minutes"), intentRes.getStringExtra("periode"),"votre QR code est"));
    }
}