package com.example.projetmobile;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class reserverActivity extends AppCompatActivity {
EditText username,mail,cin,transport,position,destination,date,heure,minute;
int periode;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserver);
        username=findViewById(R.id.username);
        mail=findViewById(R.id.cin);
        transport=findViewById(R.id.moyen);
        position=findViewById(R.id.pos);
        destination=findViewById(R.id.dest);
        date=findViewById(R.id.date);
        heure=findViewById(R.id.heurebn);
        minute=findViewById(R.id.minute);
    }

    public void validerRes(View view) {
        periode=Integer.valueOf(String.valueOf(heure))+3;
        Intent intentRes=new Intent(this,checkReserverActivity.class);
        intentRes.putExtra("username",String.valueOf(username));
        intentRes.putExtra("mail",String.valueOf(mail));
        intentRes.putExtra("cin",String.valueOf(cin));
        intentRes.putExtra("position",String.valueOf(position));
        intentRes.putExtra("destination",String.valueOf(destination));
        intentRes.putExtra("date",String.valueOf(date));
        intentRes.putExtra("heure",String.valueOf(heure));
        intentRes.putExtra("minutes",String.valueOf(minute));
        intentRes.putExtra("periode",String.valueOf(periode));
        startActivity(intentRes);
    }
}