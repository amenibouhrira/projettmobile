package com.example.projetmobile;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class inscActivity extends AppCompatActivity {
EditText username,password1,password2,cin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insc);
        username=findViewById(R.id.username);
        password1=findViewById(R.id.password1);
        password2=findViewById(R.id.password2);
        cin=findViewById(R.id.cin);

    }
    public void validerInscrit(View view) {
        Intent intentInscrit=new Intent(this,checkedSignUpActivity.class);
        Intent intentErreur=new Intent(this,errorActivity.class);
        if (password1==password2){
            intentInscrit.putExtra("username",String.valueOf(username));
            intentInscrit.putExtra("cin",String.valueOf(cin));
            startActivity(intentInscrit);
        }
        else{
            startActivity(intentErreur);

        }


    }
}