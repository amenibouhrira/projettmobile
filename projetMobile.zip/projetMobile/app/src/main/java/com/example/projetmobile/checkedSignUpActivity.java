package com.example.projetmobile;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class checkedSignUpActivity extends AppCompatActivity {
TextView res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checked_sign_up);
        res=findViewById(R.id.comptecrée);
        Intent intentInscrit =getIntent();
        res.setText(String.format("Bienvenue!%savec le num de cin%svotre compte a été créer avec succès!!!",
                intentInscrit.getStringExtra("username"),
                intentInscrit.getStringExtra("cin")));
    }
}