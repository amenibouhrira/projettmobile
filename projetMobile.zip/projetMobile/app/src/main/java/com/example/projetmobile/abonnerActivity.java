package com.example.projetmobile;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

public class abonnerActivity extends AppCompatActivity {
    EditText username,mail,cin,transport,jour,moiss,annee,destination,position;
    RadioButton mois,semestre,annee2;
    int periode;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abonner);
        EditText username=findViewById(R.id.username);
        EditText mail=findViewById(R.id.mail);
        EditText cin=findViewById(R.id.cin);
        EditText transport=findViewById(R.id.moyen);
        EditText jour=findViewById(R.id.jour);
        EditText moiss=findViewById(R.id.moiss);
        EditText annee=findViewById(R.id.anne);
        EditText position=findViewById(R.id.pos);
        EditText destination=findViewById(R.id.dest);
        RadioButton mois=findViewById(R.id.mois);
        RadioButton semestre=findViewById(R.id.semestre);
        RadioButton annee2=findViewById(R.id.annee);
    }

    public void validerabn(View view) {
        Intent intentabn=new Intent(this,checkAbonner.class);
        startActivity(intentabn);
        intentabn.putExtra("usernme", String.valueOf(username));
        intentabn.putExtra("mail", String.valueOf(mail));
        intentabn.putExtra("cin", String.valueOf(cin));
        intentabn.putExtra("transport", String.valueOf(transport));
        intentabn.putExtra("jour", String.valueOf(jour));
        intentabn.putExtra("moiss", String.valueOf(moiss));
        intentabn.putExtra("annee", String.valueOf(annee));
         intentabn.putExtra("position",String.valueOf(position));
        intentabn.putExtra("destination",String.valueOf(destination));
        intentabn.putExtra("mois", String.valueOf(mois));
        intentabn.putExtra("semestre", String.valueOf(semestre));
        intentabn.putExtra("annee", String.valueOf(annee2));
        if(mois.isChecked()){
            periode = Integer.valueOf(String.valueOf(jour)) + 30;
        }
        if (semestre.isChecked()){
            periode=Integer.valueOf(String.valueOf(moiss))+6;
        }
        if(annee2.isChecked()){
            periode=Integer.valueOf(String.valueOf(annee))+1;
        }
     intentabn.putExtra("periode",String.valueOf(periode)+String.valueOf(moiss)+String.valueOf(annee));

    }
}